var searchData=
[
  ['pressed_37',['pressed',['../class_bounce2_1_1_button.html#a3fbacfb9a631e03afcfaa5dc39686bad',1,'Bounce2::Button']]],
  ['previousduration_38',['previousDuration',['../class_debouncer.html#a89ab95e7ac24874bb8cb684dc36a98b9',1,'Debouncer']]]
];
